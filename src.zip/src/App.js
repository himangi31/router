
import {Website} from "./component/Website";
import {Items} from "./component/Items";
import {Header} from "./component/Header";
import {Fetchnodeservices} from "../src/Fetchnodeservices";
import {Itemtypes }from "./component/Itemtypes";
import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";


function App() {
  return (
    <>
      <Router> 
     
      <Switch>
          <Route exact path="/">
            <Website />
          </Route>
          <Route exact path="/itemtypes">
            <Itemtypes/>
          </Route>
          
        </Switch>
        </Router>
    </>
  );
}

export default App;

